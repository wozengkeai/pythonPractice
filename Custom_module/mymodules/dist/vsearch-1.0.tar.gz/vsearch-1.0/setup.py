# -*- coding: utf-8 -*-
"""
@Time ： 2021/10/6 14:44
@Auth ： zengxiaoyan
@File ：setup.py
"""
from setuptools import setup
setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='testerZ',
    author_email='testerZ@qq.com',
    py_modules=['vsearch'],
)